/*
 * Copyright (c) 1997, 2020 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Distribution License v. 1.0, which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/**
 * The part of public policy API that defines the classes and interfaces dealing with 
 * the policy tree structure (policy source model) creation and manipulation.
 */
package com.sun.xml.ws.policy.sourcemodel;
